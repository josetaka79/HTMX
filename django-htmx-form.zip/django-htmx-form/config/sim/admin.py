from django.contrib import admin
from .models import ContactSubmission

@admin.register(ContactSubmission)
class ContactSubmissionAdmin(admin.ModelAdmin):
    list_display = ("name", "surname", "email", "phone", "created_at")
    search_fields = ("name", "surname", "email", "phone")
    list_filter = ("created_at",)
    ordering = ("-created_at",)




