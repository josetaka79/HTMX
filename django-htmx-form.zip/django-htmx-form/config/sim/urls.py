from django.urls import path
from .views import home, register, user_form, success

urlpatterns = [
    path('', home, name='home'),
    path('register/', register, name='register'),
    path('form/', user_form, name='user_form'),
    path('success/', success, name='success'),
]







