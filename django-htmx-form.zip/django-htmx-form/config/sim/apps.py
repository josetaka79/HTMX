from django.apps import AppConfig


class SimConfig(AppConfig):
    name = 'sim'
