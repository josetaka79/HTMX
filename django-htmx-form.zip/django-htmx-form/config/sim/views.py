from django.shortcuts import render, redirect
from django.contrib.auth import login
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.decorators import login_required
from .forms import StepOneForm
from .models import ContactSubmission

def home(request):
    return render(request, "home.html")

def register(request):
    if request.method == "POST":
        form = UserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            return redirect("user_form")
    else:
        form = UserCreationForm()

    return render(request, "register.html", {"form": form})

@login_required
def user_form(request):
    if request.user.is_staff:
        return redirect("/admin/")

    if request.method == "POST":
        form = StepOneForm(request.POST)
        if form.is_valid():
            ContactSubmission.objects.create(
                name=form.cleaned_data["name"],
                surname=form.cleaned_data["surname"],
                email=form.cleaned_data["email"],
                phone=form.cleaned_data["phone"],
                message=form.cleaned_data["message"],
            )
            return redirect("success")
    else:
        form = StepOneForm()

    return render(request, "step_one.html", {"form": form})

def success(request):
    return render(request, "success.html")





