from django.urls import path
from . import views

urlpatterns = [
    path('', views.step_one, name='step-one'),
    path('step-one-submit/', views.step_one_submit, name='step-one-submit'),
    path('contact/', views.contact, name='contact'),
    path('contact-submit/', views.contact_submit, name='contact-submit'),
]


