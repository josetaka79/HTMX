from django.shortcuts import render
from django.http import HttpResponse


# ---------- STEP 1 ----------
def step_one(request):
    return render(request, "step_one.html")


def step_one_submit(request):
    name = request.POST.get("name")
    email = request.POST.get("email")
    colour = request.POST.get("favourite_color")

    if name and email and colour:
        # HTMX redirect
        response = HttpResponse()
        response["HX-Redirect"] = "/contact/"
        return response

    return HttpResponse(
        '<p class="error">Please fill all fields ❌</p>'
    )


# ---------- STEP 2 ----------
def contact(request):
    return render(request, "contact.html")


def contact_submit(request):
    name = request.POST.get("name")
    surname = request.POST.get("surname")
    phone = request.POST.get("phone")
    email = request.POST.get("email")
    message = request.POST.get("message")

    if all([name, surname, phone, email, message]):
        return HttpResponse(
            '<p class="success">Thank you! Your message was sent ✅</p>'
        )

    return HttpResponse(
        '<p class="error">Please complete all fields ❌</p>'
    )



