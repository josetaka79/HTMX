from django.contrib import admin
from .models import Customer, Note

@admin.register(Customer)
class CustomerAdmin(admin.ModelAdmin):
    list_display = ('name', 'email', 'company')
    search_fields = ('name', 'email', 'company')


@admin.register(Note)
class NoteAdmin(admin.ModelAdmin):
    list_display = ('customer', 'content')
    search_fields = ('customer__name', 'content')
    list_filter = ('customer',)

