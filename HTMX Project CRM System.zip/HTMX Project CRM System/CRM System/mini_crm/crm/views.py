from django.shortcuts import render, get_object_or_404
from django.http import HttpResponse
from .models import Customer
from .forms import CustomerForm


def customer_list(request):
    customers = Customer.objects.all()
    return render(request, "customers/customer_list.html", {"customers": customers})


def customer_create(request):
    if request.method == "POST":
        form = CustomerForm(request.POST)
        if form.is_valid():
            customer = form.save()
            return render(
                request,
                "customers/partials/customer_row.html",
                {"customer": customer}
            )
    else:
        form = CustomerForm()

    return render(
        request,
        "customers/partials/customer_form.html",
        {"form": form}
    )


def customer_edit(request, pk):
    customer = get_object_or_404(Customer, pk=pk)

    if request.method == "POST":
        form = CustomerForm(request.POST, instance=customer)
        if form.is_valid():
            customer = form.save()
            return render(
                request,
                "customers/partials/customer_row.html",
                {"customer": customer}
            )
    else:
        form = CustomerForm(instance=customer)

    return render(
        request,
        "customers/partials/customer_form.html",
        {"form": form, "customer": customer}
    )


def customer_delete(request, pk):
    customer = get_object_or_404(Customer, pk=pk)
    customer.delete()
    return HttpResponse("")


